from setuptools import setup

if __name__ == '__main__':
    setup(name='logic-gates-model', packages=['logic-gates-model'])
